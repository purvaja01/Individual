import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';

// import { Link } from "react-router-dom";

export const Signup = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setpass] = useState("");
  const [id, setid] = useState("");
  const [FullName, setname] = useState("");
  const [cpass, setcpass] = useState("");

  const handlesubmit = async () => {
    const data = {
        id : id,
        name : FullName,
        email : email,
        password : pass
    }
    if(id !== "" && FullName !== "" && email !== "" && pass !== "" && cpass !== ""){
      try{
        const response = await axios.post("http://localhost:8090/Signup",data);
        console.log(response);
      }
      catch(error) {
          console.log("error:", error);
      }
    }
      if (pass === cpass) {
        let availableEmail = false;

        Object.keys(localStorage).forEach((exists) => {
          if (exists === email) {
            availableEmail = true;
          }
        });

        if (availableEmail === false) {
          const data = {
            fullname:FullName,
            id:id,
            password:pass
          }

          localStorage.setItem(email, JSON.stringify(data));

          alert("Registered Successfully");

          navigate("/");
        } else {
          alert("Email Already Exist");
        }
      } else {
        alert("Password does not Match");
      }
    
    
  } ;

  return (
    <div className="auth-form-container">
      <form className="signup-form">
        <label>id</label>
        <br />
        <input htmlFor="id"  type="text" onChange={(e)=> setid(e.target.value)} required />
        <br />
        <label>Name</label>
        <br />
        <input htmlFor="FullName"  type="text" onChange={(e)=> setname(e.target.value)} required />
        <br />
        <label>Email</label>
        <br />
        <input
          htmlFor="email"
          
          type="email"
          placeholder="youremail@gmail.com" onChange={(e)=> setEmail(e.target.value)} required
        />
        <br />
        <label>Password</label>
        <br />
        <input
          htmlFor="Password"
          
          type="password"
          placeholder="**********"
          id="password"
          name="password" onChange={(e)=> setpass(e.target.value)} required
        />
        <br />
        <label>Confirm Passowrd</label>
        <br />
        <input
          htmlFor="Confirm Passowrd"
          
          type="password"
          placeholder="**********"
          id="cpassword"
          name="cpassword" onChange={(e)=> setcpass(e.target.value)} required
        />
        <br />
        <br />
        <button onClick={handlesubmit}>Sign Up</button>
      </form>
      <button className="link-btn">
        <Link to="/">Already have an Account? Signin here.</Link>
      </button>
    </div>
  );
  };

export default Signup;
